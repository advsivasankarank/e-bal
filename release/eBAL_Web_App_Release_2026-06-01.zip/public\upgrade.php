<?php
require_once __DIR__ . '/../app/session_bootstrap.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../app/helpers/plan_helper.php';

$userId = (int) ($_SESSION['user_id'] ?? 0);
$plan = $userId > 0 ? getUserPlan($userId, $pdo) : null;
$usage = $userId > 0 ? getPlanUsage($pdo, $userId) : null;
$plans = getPlanCatalog($pdo);

$page_title = 'Upgrade Plan';
require_once __DIR__ . '/layouts/header.php';
?>

<div class="page-title">Upgrade Plan</div>

<?php if (!empty($_SESSION['error'])): ?>
    <div class="error-box"><p><?= htmlspecialchars($_SESSION['error']) ?></p></div>
<?php endif; ?>

<style>
.upgrade-grid { display:grid; grid-template-columns:1.2fr 1fr; gap:18px; }
.upgrade-plans { display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; }
.upgrade-plan { border:1px solid #d8e2ef; border-radius:14px; padding:18px; background:#fff; position:relative; }
.upgrade-plan.is-current { border-color:#0f766e; box-shadow:0 12px 28px rgba(15, 118, 110, 0.12); }
.upgrade-badge { position:absolute; top:14px; right:14px; background:#0f766e; color:#fff; border-radius:999px; padding:4px 10px; font-size:12px; font-weight:700; }
.upgrade-price { font-size:28px; font-weight:700; color:#0f172a; margin:8px 0; }
.upgrade-list { margin:12px 0 0 18px; line-height:1.7; }
.usage-grid { display:grid; grid-template-columns:repeat(3, minmax(120px, 1fr)); gap:12px; margin-top:14px; }
.usage-box { border:1px solid #d8e2ef; border-radius:12px; padding:14px; background:#f8fbff; }
.usage-box strong { display:block; font-size:22px; color:#0f172a; }
@media (max-width: 920px) { .upgrade-grid, .usage-grid { grid-template-columns:1fr; } }
</style>

<div class="upgrade-grid">
    <div class="card section-card">
        <strong>Current Plan</strong><br>
        <?php if ($plan && $usage): ?>
            <div style="margin-top:12px; font-size:18px; font-weight:700; color:#0f172a;"><?= htmlspecialchars($plan['plan_name']) ?></div>
            <div style="color:#64748b; margin-top:4px;">Expires on <?= htmlspecialchars($plan['expires_at']) ?></div>
            <div class="usage-grid">
                <div class="usage-box">
                    <span>Companies</span>
                    <strong><?= (int) $usage['companies_used'] ?> / <?= (int) $usage['company_limit'] ?></strong>
                </div>
                <div class="usage-box">
                    <span>Users</span>
                    <strong><?= (int) $usage['users_used'] ?> / <?= (int) $usage['user_limit'] ?></strong>
                </div>
                <div class="usage-box">
                    <span>AI</span>
                    <strong><?= !empty($usage['ai_enabled']) ? 'On' : 'Off' ?></strong>
                </div>
            </div>
            <p style="margin-top:14px; color:#64748b;"><?= htmlspecialchars((string) ($usage['description_text'] ?? '')) ?></p>
            <div style="margin-top:12px;">
                <span class="status">Plan changes are controlled by superadmin.</span>
            </div>
        <?php else: ?>
            <p style="margin-top:12px;">No active license found. Assign a commercial plan from Workspace Admin to start using e-BAL as a managed product.</p>
            <span class="status">Contact superadmin for activation.</span>
        <?php endif; ?>
    </div>

    <div class="card section-card">
        <strong>Commercial Rollout Notes</strong>
        <ul class="upgrade-list">
            <li>Starter: 5 companies, 1 user, annual price ₹2,999.</li>
            <li>Professional: 10 companies, 3 users, annual price ₹4,999.</li>
            <li>Pro Plus: Unlimited companies, 5 users, annual price ₹9,999.</li>
            <li>AI-assisted drafting is available from Professional upwards.</li>
        </ul>
    </div>
</div>

<div class="card section-card">
    <strong>Available Plans</strong>
    <div class="upgrade-plans" style="margin-top:16px;">
        <?php foreach ($plans as $planRow): ?>
            <?php $isCurrent = $plan && $plan['plan'] === $planRow['code']; ?>
            <div class="upgrade-plan <?= $isCurrent ? 'is-current' : '' ?>">
                <?php if ($isCurrent): ?><div class="upgrade-badge">Current</div><?php endif; ?>
                <h3><?= htmlspecialchars($planRow['name']) ?></h3>
                <div class="upgrade-price">₹<?= number_format((int) $planRow['price_inr']) ?><span style="font-size:14px; font-weight:500; color:#64748b;">/year</span></div>
                <ul class="upgrade-list">
                    <li><?= (int) $planRow['company_limit'] >= 999 ? 'Unlimited companies' : ((int) $planRow['company_limit'] . ' companies') ?></li>
                    <li><?= (int) $planRow['user_limit'] ?> users</li>
                    <li><?= (int) $planRow['ai_enabled'] === 1 ? 'AI drafting included' : 'AI drafting not included' ?></li>
                </ul>
                <p style="margin-top:12px; color:#64748b;"><?= htmlspecialchars($planRow['description_text']) ?></p>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php
unset($_SESSION['error']);
require_once __DIR__ . '/layouts/footer.php';
?>
